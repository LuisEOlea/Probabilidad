function mostrar(elemento) { 
    elemento.classList.remove('oculto'); 
}

function ocultar(elemento) { 
    elemento.classList.add('oculto'); 
}

function ocultarTodos() {
    document.querySelectorAll('.pregunta, #btnCalcular, #reinicio, #despedida').forEach(elem => ocultar(elem));
}

// Flujo de preguntas
document.querySelectorAll('input[name="p1"]').forEach(radio => {
    radio.addEventListener('change', () => {
        const valor = radio.value;
        if (valor === 'si') {
            ocultar(document.getElementById('p2'));
            mostrar(document.getElementById('fcpInputs'));
            mostrar(document.getElementById('btnCalcular'));
        } else {
            ocultar(document.getElementById('fcpInputs'));
            mostrar(document.getElementById('p2'));
            mostrar(document.getElementById('btnCalcular'));
        }
    });
});

document.querySelectorAll('input[name="p2"]').forEach(radio => {
    radio.addEventListener('change', () => {
        const valor = radio.value;
        if (valor === 'no') {
            ocultarTodos();
            mostrar(document.getElementById('parametros'));
            mostrar(document.getElementById('btnCalcular'));
        } else {
            ocultarTodos();
            mostrar(document.getElementById('p3'));
            mostrar(document.getElementById('btnCalcular'));
        }
    });
});

document.querySelectorAll('input[name="p3"]').forEach(radio => {
    radio.addEventListener('change', () => {
        const valor = radio.value;
        if (valor === 'si') {
            ocultarTodos();
            mostrar(document.getElementById('p4'));
            mostrar(document.getElementById('btnCalcular'));
        } else {
            ocultarTodos();
            mostrar(document.getElementById('parametros'));
            mostrar(document.getElementById('btnCalcular'));
        }
    });
});

document.querySelectorAll('input[name="p4"]').forEach(radio => {
    radio.addEventListener('change', () => {
        const valor = radio.value;
        if (valor === 'si') {
            ocultarTodos();
            mostrar(document.getElementById('circularInputs'));
            mostrar(document.getElementById('btnCalcular'));
        } else {
            ocultarTodos();
            mostrar(document.getElementById('p5'));
            mostrar(document.getElementById('btnCalcular'));
        }
    });
});

document.querySelectorAll('input[name="p5"]').forEach(radio => {
    radio.addEventListener('change', () => {
        const valor = radio.value;
        if (valor === 'si') {
            ocultarTodos();
            mostrar(document.getElementById('multisetInputs'));
            mostrar(document.getElementById('btnCalcular'));
            // Mostrar elementos de repeticiones
            document.getElementById('kRep').parentElement.style.display = 'block';
            document.getElementById('countInputsContainer').style.display = 'block';
            document.querySelector('button[onclick="generarCampos()"]').style.display = 'block';
        } else {
            ocultarTodos();
            mostrar(document.getElementById('multisetInputs'));
            mostrar(document.getElementById('btnCalcular'));
            // Ocultar elementos de repeticiones
            document.getElementById('kRep').parentElement.style.display = 'none';
            document.getElementById('countInputsContainer').style.display = 'none';
            document.querySelector('button[onclick="generarCampos()"]').style.display = 'none';
        }
    });
});

function generarCampos() {
    const k = parseInt(document.getElementById('kRep').value);
    const container = document.getElementById('countInputsContainer');
    container.innerHTML = '';
    for (let i = 0; i < k; i++) {
        const label = document.createElement('label');
        label.textContent = `Repeticiones de elemento ${i+1}: `;
        const input = document.createElement('input');
        input.type = 'number';
        input.id = `count${i}`;
        container.appendChild(label);
        container.appendChild(input);
        container.appendChild(document.createElement('br'));
    }
}

function calcular() {
    const resp1 = document.querySelector('input[name="p1"]:checked')?.value;
    const resp2 = document.querySelector('input[name="p2"]:checked')?.value;
    const resp3 = document.querySelector('input[name="p3"]:checked')?.value;
    const resp4 = document.querySelector('input[name="p4"]:checked')?.value;
    const resp5 = document.querySelector('input[name="p5"]:checked')?.value;

    if (resp1 === 'si') {
        // Principio Fundamental del Conteo
        const valores = document.getElementById('fcpValores').value.split(',').map(Number);
        const resultado = valores.reduce((a, b) => a * b, 1);
        mostrarResultado(`Producto de opciones: ${valores.join(' × ')} = ${resultado.toLocaleString()}`);
        return;
    }

    if (resp2 === 'no') {
        // Combinaciones
        const n = parseInt(document.getElementById('n').value);
        const r = parseInt(document.getElementById('r').value);
        const resultado = factorial(n) / (factorial(r) * factorial(n - r));
        mostrarResultado(`Combinaciones (${n}C${r}): ${n}! / (${r}! × ${n - r}!) = ${resultado.toLocaleString()}`);
        return;
    }

    if (resp3 === 'no') {
        // Permutaciones de r elementos
        const n = parseInt(document.getElementById('n').value);
        const r = parseInt(document.getElementById('r').value);
        const resultado = factorial(n) / factorial(n - r);
        mostrarResultado(`Permutaciones (${n}P${r}): ${n}! / (${n - r}!) = ${resultado.toLocaleString()}`);
        return;
    }

    if (resp4 === 'si') {
        // Permutaciones circulares
        const n = parseInt(document.getElementById('nCir').value);
        const resultado = factorial(n - 1);
        mostrarResultado(`Permutaciones circulares: (${n}-1)! = ${resultado.toLocaleString()}`);
        return;
    }

    if (resp5 === 'si') {
        // Permutaciones con objetos repetidos
        const nTotal = parseInt(document.getElementById('nTotal').value);
        const k = parseInt(document.getElementById('kRep').value);
        const counts = [];
        let sum = 0;
        for (let i = 0; i < k; i++) {
            const count = parseInt(document.getElementById(`count${i}`).value);
            counts.push(count);
            sum += count;
        }
        if (sum > nTotal) {
            alert('Error: La suma de repeticiones no puede superar el total de elementos');
            return;
        }
        const denominador = counts.reduce((acc, val) => acc * factorial(val), 1);
        const resultado = factorial(nTotal) / denominador;
        const repeticiones = counts.map((v, i) => `n${i+1}=${v}`).join(', ');
        mostrarResultado(`Permutaciones con objetos repetidos: ${nTotal}! / (${counts.map(v => v + '!').join(' × ')}) = ${resultado.toLocaleString()}`);
        return;
    }

    // Permutaciones lineales sin repeticiones (nuevo caso)
    if (resp3 === 'si' && resp4 === 'no' && resp5 === 'no') {
        const nTotal = parseInt(document.getElementById('nTotal').value);
        if (isNaN(nTotal)) {
            alert('Por favor, ingrese el valor de n');
            return;
        }
        const resultado = factorial(nTotal);
        mostrarResultado(`Permutaciones lineales: ${nTotal}! = ${resultado.toLocaleString()}`);
        return;
    }
}

function mostrarResultado(formula) {
    document.getElementById('resultado').innerHTML = `
        <h3>Resultado:</h3>
        <p>${formula}</p>
    `;
    mostrar(document.getElementById('resultado'));
    ocultar(document.getElementById('btnCalcular'));
    mostrar(document.getElementById('reinicio'));
}

function reiniciar() {
    document.querySelectorAll('input').forEach(input => {
        if (input.type === 'radio') input.checked = false;
        else input.value = '';
    });
    document.querySelectorAll('.pregunta, #btnCalcular').forEach(elem => ocultar(elem));
    document.getElementById('countInputsContainer').innerHTML = '';
    ocultar(document.getElementById('reinicio'));
    ocultar(document.getElementById('despedida'));
    mostrar(document.getElementById('p1'));
    mostrar(document.getElementById('btnCalcular'));
    // Restablecer visibilidad de elementos de repeticiones
    document.getElementById('kRep').parentElement.style.display = 'block';
    document.querySelector('button[onclick="generarCampos()"]').style.display = 'block';
}

function finalizar() {
    ocultar(document.getElementById('reinicio'));
    ocultar(document.getElementById('resultado'));
    mostrar(document.getElementById('despedida'));
}

function factorial(num) {
    if (num === 0 || num === 1) return 1;
    return num * factorial(num - 1);
}