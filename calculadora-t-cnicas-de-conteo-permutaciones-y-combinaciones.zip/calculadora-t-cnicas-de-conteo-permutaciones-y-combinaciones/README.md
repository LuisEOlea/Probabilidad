# Calculadora "Técnicas de Conteo: permutaciones y combinaciones"

A Pen created on CodePen.

Original URL: [https://codepen.io/LUIS-ENRIQUE-OLEA-OSUNA/pen/OPJmRjY](https://codepen.io/LUIS-ENRIQUE-OLEA-OSUNA/pen/OPJmRjY).

Herramienta para calcular el número de formas en las que puede ocurrir un evento, dadas condiciones como si son eventos en sucesión, si importa o no el orden, si los objetos se acomodan en arreglo lineal o circular y si en la permutación hay objetos que se repiten.