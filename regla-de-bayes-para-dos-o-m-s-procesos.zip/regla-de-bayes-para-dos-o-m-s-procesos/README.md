# Regla de Bayes para dos o más procesos.

A Pen created on CodePen.

Original URL: [https://codepen.io/LUIS-ENRIQUE-OLEA-OSUNA/pen/XJWjPgy](https://codepen.io/LUIS-ENRIQUE-OLEA-OSUNA/pen/XJWjPgy).

Herramienta que permite calcular la probabilidad de que una parte de un proceso sea la responsable de un resultado, favorable o desfavorable.
Incluye la posibilidad de adaptar la herramienta para dos o más procesos.