function generateInputs() {
  const numProcesses = parseInt(document.getElementById('numProcesses').value);
  if (isNaN(numProcesses) || numProcesses < 2) {
    document.getElementById('error').textContent = 'Por favor, ingrese un número válido de procesos (Mínimo 2).';
    return;
  }

  const inputsDiv = document.getElementById('inputs');
  inputsDiv.innerHTML = ''; // Limpiar campos anteriores

  for (let i = 1; i <= numProcesses; i++) {
    const machineDiv = document.createElement('div');
    machineDiv.classList.add('machine-group');
    machineDiv.innerHTML = `
      <h3>Máquina ${String.fromCharCode(64 + i)}:</h3>
      <div class="input-group">
        <label for="usage${i}">Probabilidad de uso de la máquina ${String.fromCharCode(64 + i)} (%):</label>
        <input type="number" step="0.01" min="0" max="100" id="usage${i}" placeholder="Ejemplo: 20">
      </div>
      <div class="input-group">
        <label for="efficiency${i}">Eficiencia de la máquina ${String.fromCharCode(64 + i)} (%):</label>
        <input type="number" step="0.01" min="0" max="100" id="efficiency${i}" placeholder="Ejemplo: 85">
      </div>
    `;
    inputsDiv.appendChild(machineDiv);
  }

  // Mostrar el botón de cálculo
  document.getElementById('calculateButton').style.display = 'block';
  document.getElementById('error').textContent = '';
}

function calculateBayes() {
  const numProcesses = parseInt(document.getElementById('numProcesses').value);
  let totalUsage = 0;
  const usages = [];
  const efficiencies = [];

  for (let i = 1; i <= numProcesses; i++) {
    const usage = parseFloat(document.getElementById(`usage${i}`).value) || 0;
    const efficiency = parseFloat(document.getElementById(`efficiency${i}`).value) || 0;

    if (isNaN(usage) || isNaN(efficiency)) {
      document.getElementById('error').textContent = `Por favor, complete todos los valores para la máquina ${String.fromCharCode(64 + i)}.`;
      return;
    }

    usages.push(usage / 100);
    efficiencies.push(efficiency / 100);
    totalUsage += usage;
  }

  if (Math.abs(totalUsage - 100) > 0.01) {
    document.getElementById('error').textContent = 'La suma de las probabilidades de uso debe ser igual a 100%.';
    return;
  }

  // Calcular la probabilidad total de acierto
  let totalSuccess = 0;
  for (let i = 0; i < numProcesses; i++) {
    totalSuccess += usages[i] * efficiencies[i];
  }

  // Calcular las probabilidades condicionales usando la Regla de Bayes
  const resultsDiv = document.getElementById('outputResults');
  resultsDiv.innerHTML = ''; // Limpiar resultados anteriores

  for (let i = 0; i < numProcesses; i++) {
    const bayes = (usages[i] * efficiencies[i]) / totalSuccess;
    const resultP = document.createElement('p');
    resultP.textContent = `Probabilidad de que el resultado sea por la máquina ${String.fromCharCode(65 + i)}: ${(bayes * 100).toFixed(2)}%`;
    resultsDiv.appendChild(resultP);
  }

  document.getElementById('error').textContent = '';
}