function calculateBayes() {
  // Obtener valores de entrada
  const usageA = parseFloat(document.getElementById('usageA').value) || 0;
  const efficiencyA = parseFloat(document.getElementById('efficiencyA').value) || 0;
  const usageB = parseFloat(document.getElementById('usageB').value) || 0;
  const efficiencyB = parseFloat(document.getElementById('efficiencyB').value) || 0;
  const usageC = parseFloat(document.getElementById('usageC').value) || 0;
  const efficiencyC = parseFloat(document.getElementById('efficiencyC').value) || 0;

  // Validar que las probabilidades de uso sumen 100%
  const totalUsage = usageA + usageB + usageC;
  if (Math.abs(totalUsage - 100) > 0.01) {
    document.getElementById('error').textContent = 'La suma de las probabilidades de uso debe ser igual a 100%.';
    return;
  }

  // Convertir porcentajes a decimales
  const usageADecimal = usageA / 100;
  const efficiencyADecimal = efficiencyA / 100;
  const usageBDecimal = usageB / 100;
  const efficiencyBDecimal = efficiencyB / 100;
  const usageCDecimal = usageC / 100;
  const efficiencyCDecimal = efficiencyC / 100;

  // Calcular la probabilidad total de acierto
  const totalSuccess = 
    (usageADecimal * efficiencyADecimal) +
    (usageBDecimal * efficiencyBDecimal) +
    (usageCDecimal * efficiencyCDecimal);

  // Calcular las probabilidades condicionales usando la Regla de Bayes
  const bayesA = (usageADecimal * efficiencyADecimal) / totalSuccess;
  const bayesB = (usageBDecimal * efficiencyBDecimal) / totalSuccess;
  const bayesC = (usageCDecimal * efficiencyCDecimal) / totalSuccess;

  // Mostrar resultados
  document.getElementById('error').textContent = '';
  document.getElementById('resultA').textContent = `Probabilidad de que el acierto/fallo sea de la máquina A: ${(bayesA * 100).toFixed(2)}%`;
  document.getElementById('resultB').textContent = `Probabilidad de que el acierto/fallo sea de la máquina B: ${(bayesB * 100).toFixed(2)}%`;
  document.getElementById('resultC').textContent = `Probabilidad de que el acierto/fallo sea de la máquina C: ${(bayesC * 100).toFixed(2)}%`;
}