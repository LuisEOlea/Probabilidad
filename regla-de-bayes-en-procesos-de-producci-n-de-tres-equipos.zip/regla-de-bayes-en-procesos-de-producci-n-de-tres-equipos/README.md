# Regla de Bayes en procesos de producción de tres equipos.

A Pen created on CodePen.

Original URL: [https://codepen.io/LUIS-ENRIQUE-OLEA-OSUNA/pen/mydrxLY](https://codepen.io/LUIS-ENRIQUE-OLEA-OSUNA/pen/mydrxLY).

Herramienta para estimar la probabilidad que le corresponde a cada una de las tres partes del proceso, sea responsable por un acierto o fallo producido en el mismo. 