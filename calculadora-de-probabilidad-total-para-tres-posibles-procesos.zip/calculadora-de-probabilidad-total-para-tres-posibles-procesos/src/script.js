function calculateProbability() {
  // Obtener valores de entrada
  const usageA = parseFloat(document.getElementById('usageA').value) || 0;
  const failureA = parseFloat(document.getElementById('failureA').value) || 0;
  const usageB = parseFloat(document.getElementById('usageB').value) || 0;
  const failureB = parseFloat(document.getElementById('failureB').value) || 0;
  const usageC = parseFloat(document.getElementById('usageC').value) || 0;
  const failureC = parseFloat(document.getElementById('failureC').value) || 0;

  // Validar que las probabilidades de uso sumen 100%
  const totalUsage = usageA + usageB + usageC;
  if (Math.abs(totalUsage - 100) > 0.01) {
    document.getElementById('error').textContent = 'La suma de las probabilidades de uso debe ser igual a 100%.';
    return;
  }

  // Convertir porcentajes a decimales
  const usageADecimal = usageA / 100;
  const failureADecimal = failureA / 100;
  const usageBDecimal = usageB / 100;
  const failureBDecimal = failureB / 100;
  const usageCDecimal = usageC / 100;
  const failureCDecimal = failureC / 100;

  // Calcular la probabilidad total de fallo
  const totalFailure = 
    (usageADecimal * failureADecimal) +
    (usageBDecimal * failureBDecimal) +
    (usageCDecimal * failureCDecimal);

  // Mostrar resultados
  document.getElementById('error').textContent = '';
  document.getElementById('totalFailure').textContent = `Probabilidad total de que una pieza sea defectuosa: ${(totalFailure * 100).toFixed(2)}%`;
}
