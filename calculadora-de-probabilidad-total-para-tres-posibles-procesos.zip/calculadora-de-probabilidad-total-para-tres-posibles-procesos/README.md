# Calculadora de probabilidad total para tres posibles procesos.

A Pen created on CodePen.

Original URL: [https://codepen.io/LUIS-ENRIQUE-OLEA-OSUNA/pen/pvoEppV](https://codepen.io/LUIS-ENRIQUE-OLEA-OSUNA/pen/pvoEppV).

Esta herramienta permite estimar la probabilidad total que que haya fallos o aciertos en un proceso con tres distintas entradas, cada una de ellas asociadas a su probabilidad de éxito o fallo.